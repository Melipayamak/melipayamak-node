const express = require('express')
const MelipayamakApi = require('melipayamak-api')
const app = express()
const port = 3000

app.get('/rest', function(req, res) { 
	
	const username = 'username';
    const password = 'password';
    const api = new MelipayamakApi(username,password);
    const sms = api.sms();
    const to = '09123456789';
    const from = '5000...';
    const text = 'تست وب سرویس ملی پیامک';
    sms.send(to, from, text).then(response => {
        res.send(response)
    }).catch(err => {
        res.send(err)
    })

})

app.get('/soap', function(req, res) { 
	
	const username = 'username';
    const password = 'password';
    const api = new MelipayamakApi(username,password);
    const sms = api.sms('soap');
    const to = '09123456789';
    const from = '5000...';
    const text = 'تست وب سرویس ملی پیامک';
    sms.send(to, from, text).then(response => {
        res.send(response)
    }).catch(err => {
        res.send(err)
    })

})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))